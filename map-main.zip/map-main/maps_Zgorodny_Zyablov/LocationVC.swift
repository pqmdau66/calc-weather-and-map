//
//  ViewController.swift
//  maps_Zgorodny_Zyablov
//
//  Created by Даниил on 20.12.2021.
//

import UIKit

class LocationVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

